<template>
  <div id="app">
    <BingoCard />
  </div>
</template>

<script>
import BingoCard from './BingoCard.vue'

export default {
  name: 'App',
  components: {
    BingoCard,
  },
}
</script>
